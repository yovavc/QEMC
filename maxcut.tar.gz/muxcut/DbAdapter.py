class DbAdapter:
    cur = None
    experiment_id = 0
    iteration_id = 0
    conn = None
    def __init__(self):
        import mariadb
        import sys

        # Connect to MariaDB Platform
        try:
            self.conn = mariadb.connect(
                user="root",
                password="root",
                host="localhost",
                port=3306,
                database="maxcut"

            )
            self.conn.autocommit = True
        except mariadb.Error as e:
            print(f"Error connecting to MariaDB Platform: {e}")
            sys.exit(1)

        # Get Cursor
        self.cur = self.conn.cursor()

    def new_experiment(self, graph, expected_blacks, node_count, number_of_layers, is_entangled,
                       number_of_steps, init, comment="", step_size=0.2, beta1=0.9, beta2=0.99, eps=1e-08):
        self.cur.execute(
            "INSERT INTO `maxcut`.`experiments` (`graph`, `expected_blacks`, `graphNodeCount`, `numberOfLayer`, `isEntangled`, `comment`, `stepSize`, `beta1`, `beta2`, `epsilon`, `numberOfSteps`, `init`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (graph, expected_blacks, node_count, number_of_layers, is_entangled, comment, step_size,
             beta1, beta2, eps, number_of_steps, init))
        self.experiment_id = self.cur.lastrowid

    def add_iteration(self, index):
        self.cur.execute("INSERT INTO iterations (`experimentId`, `iterationIndex`) VALUES (?,?)", (self.experiment_id, index))

        self.iteration_id = self.cur.lastrowid

    def add_loss(self, value):
        self.cur.execute("INSERT INTO loss (`value`, `iterationId`) VALUES (?,?)", (value, self.iteration_id))

    def add_muxcut(self, value):
        self.cur.execute("INSERT INTO maxcut (`value`, `iterationId`) VALUES (?,?)", (value, self.iteration_id))

    def add_group(self, value):
        self.cur.execute("INSERT INTO `groups` (`value`, `iterationId`) VALUES (?,?)", (value, self.iteration_id))

    def add_probs(self, value):
        self.cur.execute("INSERT INTO `probs` (`value`, `iterationId`) VALUES (?,?)", (value, self.iteration_id))

    def add_blacks(self, value):
        self.cur.execute("INSERT INTO `blacks` (`value`, `iterationId`) VALUES (?,?)", (value, self.iteration_id))



