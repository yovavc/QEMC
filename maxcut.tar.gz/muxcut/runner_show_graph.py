import glob
import os

graphs = glob.glob("graphs/*")
graphs.sort()

for graph in graphs:
    os.system("python show_graph.py " + graph + " graph_draw/")
