import glob
import os

graphs = glob.glob("graphs/*")

for graph in graphs:

    os.system("python max_cut_exhaustive_search.py " + graph + " > graph_gt/" + os.path.basename(graph) + ".maxcut.txt")
