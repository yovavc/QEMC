from DbAdapterGraph import DbAdapterGraph
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import numpy as np

dbAdapterGraph = DbAdapterGraph()
rv2 = dbAdapterGraph.get_experiments_graph_numberoflayer_expected_blacks()
rv3 = dbAdapterGraph.get_experiments_graph_numberoflayer()
group_by_stepsize_layer = dbAdapterGraph.get_experiments_group_by_stepsize_layers_graph()
group_by_beta1_layer = dbAdapterGraph.get_experiments_group_by_stepsize_layers_graph_beta1()
rv = rv3
colors = {
    5: "blue",
    10: "orange",
    30: "brown",
    40: "red",
    60: "black",
    100: "coral",
    200: "green"
}
colors_stepsize = {
    0.02: "slategrey",
    0.04: "orange",
    0.06: "brown",
    0.08: "red",
    0.1: "black",
    0.12: "coral",
    0.14: "green",
    0.2: "blue"
}
colors_beta1 = {
    0.9: "blue",
    0.91: "orange",
    0.93: "brown",
    0.95: "red",
    0.97: "black",
    0.99: "coral",
    0.995: "green",
    0.999: "pink",
    0.8: "rosybrown",
    0.81: "darkgrey",
    0.83: "lime",
    0.85: "tan",
    0.87: "slategrey",
    0.89: "navy",
    0.895: "darkviolet",
    0.899: "plum"
}
data = {}
currentGraph = ""
stopCount = 0
for entry in group_by_stepsize_layer:
    rv8 = dbAdapterGraph.get_max_maxcut_result_set(entry["ids"])[0]
    layers = rv8["layers"]

    stepSize = rv8["stepSize"]
    graph = rv8["graph"]
    maxcut = rv8["maxAvgMaxcut"]
    if graph not in data:
        data[graph] = []
    data[graph].append((layers, stepSize, maxcut))
    stopCount += 1
    # if stopCount == 10:
    #     break

for key in data:
    # make these smaller to increase the resolution
    dx, dy = 10, 0.02
    x_boundary = 200
    y_boundary = 0.2
    # generate 2 2d grids for the x & y bounds
    y, x = np.mgrid[slice(0, y_boundary + dy, dy),
                    slice(0, x_boundary + dx, dx)]

    z = np.zeros(y.shape)

    for triple in data[key]:
        shape = z.shape
        y_index = (int)((triple[1]/y_boundary) * (shape[0]-1)) - 1
        x_index = (int)((triple[0]/x_boundary) * (shape[1]-1)) - 1
        z[y_index, x_index] = triple[2]




    # x and y are bounds, so z should be the value *inside* those bounds.
    # Therefore, remove the last value from the z array.
    z = z[:-1, :-1]
    z_min, z_max = np.abs(z).max() * (15 / 16), np.abs(z).max()
    #
    fig, ax = plt.subplots()
    c = ax.pcolor(x, y, z, cmap='GnBu', vmin=z_min, vmax=z_max)
    ax.set_title(key)
    fig.colorbar(c, ax=ax)
    plt.ylabel('Step size')
    plt.xlabel('Layers')
    # ax = axs[0, 1]
    # c = ax.pcolormesh(x, y, z, cmap='GnBu', vmin=z_min, vmax=z_max)
    # ax.set_title(key)
    # fig.colorbar(c, ax=ax)
    #
    # ax = axs[1, 1]
    # c = ax.pcolorfast(x, y, z, cmap='GnBu', vmin=z_min, vmax=z_max)
    # ax.set_title('pcolorfast')
    # fig.colorbar(c, ax=ax)

    fig.tight_layout()
    plt.show()
    plt.clf()
exit()
Z = np.random.rand(6, 10)
# for entry in group_by_beta1_layer:
#
#
#
# fig, (ax0, ax1) = plt.subplots(2, 1)
#
# c = ax0.pcolor(Z)
# ax0.set_title('default: no edges')
#
# c = ax1.pcolor(Z, edgecolors='k', linewidths=4)
# ax1.set_title('thick edges')
#
# fig.tight_layout()
# plt.show()


exit()

currentGraph = ""
currentLayer = 0
for entry in group_by_beta1_layer:
    rv5 = dbAdapterGraph.get_maxcut_result_set(entry["ids"])
    x = []
    y = []
    for record in rv5:
        x.append(record["iteration"])
        y.append(record["averageMaxcut"])
    plt.plot(x, y, color=colors_beta1[entry['beta1']])
count = 0
for item in colors_beta1.items():
    ax = plt.gca()
    plt.title(f"{entry['graph']} layers:{entry['layers']}")
    plt.ylabel('MaxCut')
    plt.xlabel('Iterations')
    plt.text(0.8, 0.1 + 0.035 * count, f"beta1 {str(item[0])}", fontsize=8, horizontalalignment='left',
                 verticalalignment='center',
                 transform=ax.transAxes,
                 color="white",
                 bbox=dict(facecolor=item[1], alpha=1))
    count += 1
plt.grid(visible=True)
plt.show()
plt.clf()
exit()
print(group_by_stepsize_layer)
currentGraph = ""
currentLayer = 0
for entry in group_by_stepsize_layer:
    rv5 = dbAdapterGraph.get_maxcut_result_set(entry["ids"])
    x = []
    y = []
    if currentGraph != entry["graph"] or currentLayer != entry["layers"]:
        if currentLayer != 0:
            count = 0
            for item in colors_stepsize.items():
                ax = plt.gca()
                plt.title(f"{entry['graph']} layers:{entry['layers']}")
                plt.ylabel('MaxCut')
                plt.xlabel('Iterations')
                plt.text(0.8, 0.1 + 0.07 * count, f"Step size {str(item[0])}", fontsize=8, horizontalalignment='left',
                             verticalalignment='center',
                             transform=ax.transAxes,
                             color="white",
                             bbox=dict(facecolor=item[1], alpha=1))
                count += 1
            plt.grid(visible=True)
            plt.show()
            plt.clf()
        currentGraph = entry["graph"]
        currentLayer = entry["layers"]

    for record in rv5:
        x.append(record["iteration"])
        y.append(record["averageMaxcut"])
    plt.plot(x, y, color=colors_stepsize[entry['stepSize']])

exit()

x1 = []
y1 = []
for entry in rv2:
    ids = entry["eid"]
    ids = ids.split(",")
    for e_id in ids:
        x1.append([])
        y1.append([])
        rv = dbAdapterGraph.get_single_experiment_maxcut(int(e_id))
        print(rv)
        for record in rv:
            x1[-1].append(record["iterationIndex"])
            y1[-1].append(record["maxcut"])
        plt.plot(x1[-1], y1[-1])
    plt.title(f"{entry['graph']} layers:{entry['numberOfLayers']} eBlacks:{entry['expectedBlacks']}")
    plt.ylabel('MaxCut')
    plt.xlabel('Iterations')
    plt.grid(visible=True)
    plt.savefig(f"{entry['graph']}_layers_{entry['numberOfLayers']}_eBlacks_{entry['expectedBlacks']}.png")
    plt.show()
    plt.clf()
exit()
currentGraph = ""
figure, axis = plt.subplots(1, 3)
for entry in rv2:

    if entry["graph"] != currentGraph:
        currentGraph = entry["graph"]
        count = 0
        for item in colors.items():
            axis[0].text(-0.2, 0.6 + 0.05 * count, f"Layer {str(item[0])}", fontsize=8, horizontalalignment='left',
                         verticalalignment='center',
                         transform=axis[0].transAxes,
                         color="white",
                         bbox=dict(facecolor=item[1], alpha=1))
            count += 1
        plt.show()
        width = 16
        height = 16 * 9 / width
        plt.rcParams["figure.figsize"] = [width, height]
        plt.rcParams["figure.autolayout"] = True
        plt.savefig(f"results/grouped/{entry['graph']}_grouped_layers.png")
        figure, axis = plt.subplots(1, 3)

    # print(entry["eid"])
    rv1 = dbAdapterGraph.get_maxcut_result_set(entry["eid"])
    x = []
    min_maxcut = []
    max_maxcut = []
    avg_maxcut = []
    for entry2 in rv1:
        x.append(entry2["iteration"])
        min_maxcut.append(entry2["minMaxcut"])
        max_maxcut.append(entry2["maxMaxcut"])
        avg_maxcut.append(entry2["averageMaxcut"])

    figure.suptitle(entry['graph'])
    axis[0].set_title(f"Min")
    axis[1].set_title(f"Max")
    axis[2].set_title(f"Avg")

    axis[0].set_ylabel('MaxCut')
    axis[0].set_xlabel('Iterations')
    axis[0].grid(visible=True)

    axis[1].set_ylabel('MaxCut')
    axis[1].set_xlabel('Iterations')
    axis[1].grid(visible=True)

    axis[2].set_ylabel('MaxCut')
    axis[2].set_xlabel('Iterations')
    axis[2].grid(visible=True)

    axis[0].plot(x, min_maxcut, color=colors[entry['numberOfLayers']], label=entry['numberOfLayers'])
    axis[1].plot(x, max_maxcut, color=colors[entry['numberOfLayers']], label=entry['numberOfLayers'])
    axis[2].plot(x, avg_maxcut, color=colors[entry['numberOfLayers']], label=entry['numberOfLayers'])
    # figure.tight_layout()

    # plt_file = directory + "/" + "avg.plt" + ".png"
    # plt.axhline(y=mean_gw, color='r', linestyle='--')
    # plt.axhline(y=avg_gw, color='g', linestyle='--')
    # # plt.savefig(plt_file)
    # plt.clf()

# plt.show()
plt.clf()
for entry in rv3:
    print(entry["eid"])
    rv1 = dbAdapterGraph.get_maxcut_result_set(entry["eid"])
    x = []
    min_maxcut = []
    max_maxcut = []
    avg_maxcut = []
    for entry2 in rv1:
        x.append(entry2["iteration"])
        min_maxcut.append(entry2["minMaxcut"])
        max_maxcut.append(entry2["maxMaxcut"])
        avg_maxcut.append(entry2["averageMaxcut"])

    plt.ylabel('MaxCut')
    plt.xlabel('Iterations')
    plt.title(f"{entry['graph']} layers:{entry['numberOfLayers']}")
    plt.grid(visible=True)

    plt.plot(x, min_maxcut, color="green")
    plt.plot(x, max_maxcut, color="red")
    plt.plot(x, avg_maxcut, color="blue")
    ax = plt.gca()
    plt.text(0.2, 0.1 + 0.1 * 2, f"max", fontsize=8, horizontalalignment='left',
             verticalalignment='center',
             transform=ax.transAxes,
             color="white",
             bbox=dict(facecolor="red", alpha=1))

    plt.text(0.2, 0.1 + 0.1 * 0, f"Min", fontsize=8, horizontalalignment='left',
             verticalalignment='center',
             transform=ax.transAxes,
             color="white",
             bbox=dict(facecolor="green", alpha=1))

    plt.text(0.2, 0.1 + 0.1 * 1, f"avg", fontsize=8, horizontalalignment='left',
             verticalalignment='center',
             transform=ax.transAxes,
             color="white",
             bbox=dict(facecolor="blue", alpha=1))

    # plt.show()
    plt.savefig(f"results/{entry['graph']}_layer_{entry['numberOfLayers']}.png")
    # plt_file = directory + "/" + "avg.plt" + ".png"
    # plt.axhline(y=mean_gw, color='r', linestyle='--')
    # plt.axhline(y=avg_gw, color='g', linestyle='--')
    # # plt.savefig(plt_file)
    plt.clf()
