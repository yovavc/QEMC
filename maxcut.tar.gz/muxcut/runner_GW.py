import glob
import os

graphs = glob.glob("regular_graphs/*")
graphs.sort()
for graph in graphs:
    print("python3 Adi_GW.py " + graph + " > regular_graph_GW/" + os.path.basename(graph) + ".gw_" +".txt")
    os.system("python3 Adi_GW.py " + graph + " > regular_graph_GW/" + os.path.basename(graph) + ".gw_" +".txt")
