class DbAdapterGraph:
    cur = None
    experiment_id = 0
    iteration_id = 0
    conn = None

    def __init__(self):
        import mariadb
        import sys

        # Connect to MariaDB Platform
        try:
            self.conn = mariadb.connect(
                user="root",
                password="root",
                host="localhost",
                port=3306,
                database="maxcut"

            )
            self.conn.autocommit = True
        except mariadb.Error as e:
            print(f"Error connecting to MariaDB Platform: {e}")
            sys.exit(1)

        # Get Cursor
        self.cur = self.conn.cursor()

    def get_experiments_graph_numberoflayer_expected_blacks(self):
        self.cur.execute(
            "select group_concat(id) as eId, graph, numberoflayer, expected_blacks, count(*) as c from experiments group by graph, numberoflayer, expected_blacks having c >= 10",
        )
        rv = []
        # Print Result-set
        for (eid, graph, numberoflayer, expected_blacks, c) in self.cur:
            rv.append({"eid": eid, "graph": graph, "numberOfLayers": numberoflayer, "expectedBlacks": expected_blacks,
                       "count": c})
        return rv

    def get_experiments_graph_numberoflayer(self):
        self.cur.execute(
            "select group_concat(id) as eId, graph, numberoflayer, expected_blacks, count(*) as c from experiments group by graph, numberoflayer having c >= 10",
        )
        rv = []
        # Print Result-set
        for (eid, graph, numberoflayer, expected_blacks, c) in self.cur:
            rv.append({"eid": eid, "graph": graph, "numberOfLayers": numberoflayer, "expectedBlacks": expected_blacks,
                       "count": c})
        return rv

    def get_single_experiment_maxcut(self, e_id):
        self.cur.execute("select iterationIndex, value from iterations left join maxcut.maxcut on `maxcut`.`iterationId` = `iterations`.`id` where iterations.experimentId = ? order by iterations.iterationIndex", (e_id,))
        rv = []
        for (iterationIndex, maxcut) in self.cur:
            rv.append({"iterationIndex": iterationIndex, "maxcut": maxcut})
        return rv

    def get_maxcut_result_set(self, ids):

        self.cur.execute(
            "select max(`experiments`. `graph`) as graph, max(`iterations`. `iterationIndex`) as iterationIndex, avg(`maxcut`. `value`) as maxcutAvg, max(`maxcut`. `value`) as maxcutMax, min(`maxcut`. `value`) as maxcutMin from iterations left join maxcut.maxcut on `maxcut`. `iterationId` = `iterations`. `id` left join experiments on `iterations`. `experimentId` = `experiments`. `id` where iterations.experimentId in (" + ids + ") group by iterationIndex order by iterationIndex"
        )
        rv = []
        for (graph, iterationIndex, maxcutAvg, maxcutMax, maxcutMin) in self.cur:
            rv.append({"graph": graph, "iteration":iterationIndex, "averageMaxcut":maxcutAvg, "maxMaxcut":maxcutMax, "minMaxcut":maxcutMin})
        return rv

    def get_max_maxcut_result_set(self, ids):
        self.cur.execute(
            f"SELECT \
                graph AS graph, MAX(avgMaxcut) as maxAvgMaxcut, layers, stepSize\
            FROM\
                (SELECT\
                    MAX(`experiments`.`graph`) AS graph,\
                        MAX(`experiments`.numberOfLayer) AS layers,\
                        MAX(`experiments`.stepSize) AS stepSize,\
                        iterationIndex,\
                        AVG(maxcut.value) AS avgMaxcut\
                FROM\
                    iterations\
                LEFT JOIN maxcut ON maxcut.iterationId = iterations.id\
                LEFT JOIN experiments ON `iterations`.`experimentId` = `experiments`.`id`\
                WHERE\
                    experimentId IN ({ids})\
                GROUP BY iterationIndex) AS qty"
        )
        rv = []
        for (graph, maxAvgMaxcut, layers, stepSize) in self.cur:
            rv.append({"graph": graph, "maxAvgMaxcut":maxAvgMaxcut, "layers":layers, "stepSize":stepSize})
        return rv

    def get_experiments_group_by_stepsize_layers_graph(self):
        self.cur.execute(
            "SELECT group_concat(id) as ids, count(*) as c, numberOfLayer, stepSize, graph FROM maxcut.experiments where graph  not like \"%regular_graphs2%\"  and numberOfLayer > 5 group by numberOfLayer, stepSize, graph order by graph, numberOfLayer"
        )
        rv = []
        for (ids, c, layers, stepSize, graph) in self.cur:
            rv.append({"ids": ids, "count": c, "layers": layers, "stepSize": stepSize, "graph": graph})
        return rv



    def get_experiments_group_by_stepsize_layers_graph_beta1(self):
        self.cur.execute(
            "select group_concat(id) as ids, count(*) as c, numberOfLayer, stepSize, graph, beta1  from maxcut.experiments where graph like \"%regular_graphs2%\" and time > '2022-04-25 08:01:53' group by numberOfLayer, stepSize, graph, beta1 order by graph, numberOfLayer"
        )
        rv = []
        for (ids, c, layers, stepSize, graph, beta1) in self.cur:
            rv.append({"ids": ids, "count": c, "layers": layers, "stepSize": stepSize, "graph": graph, "beta1": beta1})
        return rv