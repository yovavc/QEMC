from networkx.generators.random_graphs import random_regular_graph
import networkx as nx
sizes=[11,12,13,14,15]
regular = 9
for entry in sizes:
    size = 2**entry
    graph = random_regular_graph(regular, size)
    string = "regular_graphs/vertices_regular_" + str(regular) + "_size_" + str(size) + ".g6"
    nx.write_graph6(graph, string)
